# Google Maps Business Leads Scraper

Collect public business listings from Google Maps search result pages.

## Preset
**TypeScript — Crawlee + Playwright + Chrome**

Demand focus: high-intent platform or use-case keyword family. Customize and test the target-specific extraction before publishing.
