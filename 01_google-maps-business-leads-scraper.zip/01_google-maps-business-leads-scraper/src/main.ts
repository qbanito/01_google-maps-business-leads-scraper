import { Actor } from 'apify';
import { PlaywrightCrawler, Dataset } from 'crawlee';

type Input = {
  startUrls?: Array<string | { url: string }>;
  searchQueries?: string[];
  maxConcurrency?: number;
  maxRequestsPerCrawl?: number;
};

await Actor.init();
const input = (await Actor.getInput<Input>()) ?? {};

const startUrls = (input.startUrls ?? [])
  .map((x) => typeof x === 'string' ? x : x.url)
  .filter(Boolean);

if (!startUrls.length) {
  throw new Error('Provide at least one public URL in startUrls.');
}

const crawler = new PlaywrightCrawler({
  maxConcurrency: input.maxConcurrency ?? 5,
  maxRequestsPerCrawl: input.maxRequestsPerCrawl ?? 100,
  async requestHandler({ page, request }) {
    await page.waitForTimeout(1500);
    const title = await page.title();
    const text = await page.locator('body').innerText().catch(() => '');
    const links = await page.locator('a[href]').evaluateAll((els) =>
      [...new Set(els.map((e: any) => e.href).filter(Boolean))]
    );

    const emails = [...new Set(text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) ?? [])];
    const phones = [...new Set(text.match(/\+?\d[\d\s().-]{7,}\d/g) ?? [])];

    await Dataset.pushData({
      tool: "Google Maps Business Leads Scraper",
      category: "Google Maps High Demand",
      sourceUrl: request.url,
      title,
      textPreview: text.slice(0, 8000),
      emails,
      phones,
      links: links.slice(0, 500),
      scrapedAt: new Date().toISOString(),
    });
  },
});

await crawler.run(startUrls);
await Actor.exit();
