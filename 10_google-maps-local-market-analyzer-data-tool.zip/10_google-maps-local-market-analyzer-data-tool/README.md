# Google Maps Local Market Analyzer Data Tool

Collect structured local-market listing data for downstream analysis.

## Preset
**TypeScript — Crawlee + Playwright + Chrome**

Demand focus: high-intent platform or use-case keyword family. Customize and test the target-specific extraction before publishing.
